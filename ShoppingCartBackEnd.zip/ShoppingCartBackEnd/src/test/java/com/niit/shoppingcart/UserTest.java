package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

@SuppressWarnings("unused")
public class UserTest {
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		UserDAO userDAO =  (UserDAO) context.getBean("userDAO");
		User user = (User) context.getBean("user");
		
		user.setId("UG01");
		user.setName("UGName123");
		user.setEmail("UGemail");
		user.setPassword("UGpass");
		user.setContact(0);
		user.setAddress("UGaddress");
		user.setRole("admin");
		
		
	}

}
