package javax.persistance;

public class Table {

}
