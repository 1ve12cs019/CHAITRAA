package javax.persistance;

public class Transient {

}
