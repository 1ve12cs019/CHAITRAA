package javax.persistance;

public class Entity {

}
