package com.niit.shoppingcart.config;

public class DriverManagerDataSource extends org.springframework.jdbc.datasource.DriverManagerDataSource {

}
