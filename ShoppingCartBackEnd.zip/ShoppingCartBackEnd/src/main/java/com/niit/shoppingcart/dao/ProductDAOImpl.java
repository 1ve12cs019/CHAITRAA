package com.niit.shoppingcart.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.Product;

@SuppressWarnings("deprecation")
@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public ProductDAOImpl (SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
    public boolean save(Product product) {
	
    	try {
			sessionFactory.getCurrentSession().save(product);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public boolean update(Product Product) {

		try {
			sessionFactory.getCurrentSession().update(Product);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
		
	public boolean delete(Product product) {

	  try {
		sessionFactory.getCurrentSession().delete(product);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
	}

	public Product get(String id) {
		String hql = "from Product where id = " + " ' " + id + " ' ";
		@SuppressWarnings({ "rawtypes" })
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings({ "unchecked" })
		List<Product> list = query.list();
		if (list == null) {
			return null;
		} else {
			return list.get(0);
		}
	}

	@SuppressWarnings({ "unchecked" })
	public List<Product> list() {

		String hql = "from Product";

		@SuppressWarnings("rawtypes")
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		return query.list();

	}

}
