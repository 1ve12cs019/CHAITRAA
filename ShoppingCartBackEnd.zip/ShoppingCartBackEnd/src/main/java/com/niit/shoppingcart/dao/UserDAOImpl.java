package com.niit.shoppingcart.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.User;

@SuppressWarnings("deprecation")
@Repository
public class UserDAOImpl implements UserDAO{
	
	@Autowired
	private SessionFactory sessionFactory;
	 
	public UserDAOImpl  (SessionFactory sessionFactory) {
		this .sessionFactory = sessionFactory;
	}
 public boolean save(User user){
  
	 try {
		sessionFactory.getCurrentSession().save(user);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
 }
public boolean update(User user) {

	try {
		sessionFactory.getCurrentSession().update(user);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
}
public boolean delete(User user) {

	try {
		sessionFactory.getCurrentSession().delete(user);
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
}
public User get(String id) {

	String hql = "from User where id = " + " ' " + id + " ' ";
  @SuppressWarnings({ "rawtypes" })
Query query = sessionFactory.getCurrentSession().createQuery(hql);
  @SuppressWarnings({ "unchecked" })
List<User> list = query.list();
  if (list == null) {
		return null;
	} else {
		return list.get(0);
	}
}
@SuppressWarnings({ "unchecked" })
public List<User> list() {

   String hql = "from User";
   @SuppressWarnings("rawtypes")
Query query = sessionFactory.getCurrentSession().createQuery(hql);
   return query.list();
		   
}
}
