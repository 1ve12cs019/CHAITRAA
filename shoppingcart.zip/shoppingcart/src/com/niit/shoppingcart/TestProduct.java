package com.niit.shoppingcart;

public class TestProduct {
	public static void main(String[] args) {
		Product p1 = new Product(0, null);
		p1.setId(111);
		p1.setName("mobile");
		p1.setPrice(-65_000);
		
		System.out.println("ID:"+p1.getId());
		System.out.println("NAME:"+p1.getName());
		System.out.println("PRICE:"+p1.getPrice());
	}

}
