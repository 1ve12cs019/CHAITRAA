package com.niit.shoppingcart;

public class Product {
	private int id;
	private String name ;
	private int price;
	public int getId() {
		return id;
	
	
}
	public String getName() {
		return name;
	}
	public void setName(String name) {

	this.name = name;
	}
	
	public int getPrice() {
		if(price<0)
		{
		System.out.println("the price should not be-ve!default value is assigned");
		price=60_000;
		}
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setId(int id) {
		this.id = id;
	
}
	public Product(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
}